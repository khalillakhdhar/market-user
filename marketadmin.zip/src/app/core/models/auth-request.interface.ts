export interface AuthRequest {
  userName: string;
  password: string;
}
