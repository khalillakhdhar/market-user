// Chart data
export interface ChartType {
    chart?: any;
    plotOptions?: any;
    colors?: any;
    series?: any;
    yaxis?: any;
    dataLabels?: any;
    xaxis?: any;
}
