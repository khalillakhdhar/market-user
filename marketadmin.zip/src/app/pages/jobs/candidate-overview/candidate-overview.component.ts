import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-overview',
  templateUrl: './candidate-overview.component.html',
  styleUrls: ['./candidate-overview.component.scss']
})

/**
 * Candidate Overview Component
 */
export class CandidateOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
