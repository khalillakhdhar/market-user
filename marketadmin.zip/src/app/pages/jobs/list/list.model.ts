export interface jobListModel {
  id: number;
  title: string;
  name: string;
  location: string;
  experience: string;
  position: any;
  type: any;
  type_color: any;
  posted_date: any;
  last_date: any;
  status: any;
  status_color: any;
}
